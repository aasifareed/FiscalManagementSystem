﻿namespace FiscalManagementSystem
{
    public class FiscalManagementSystemConsts
    {
        public const string LocalizationSourceName = "FiscalManagementSystem";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
